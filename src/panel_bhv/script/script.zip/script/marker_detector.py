#!/usr/bin/env python3

import py_trees
import rospy
from fiducial_msgs.msg import FiducialTransformArray
import tf
from fiducial_msgs.msg import FiducialTransformArray

class Aruco_Detector(py_trees.behaviour.Behaviour):
    def __init__(self, name, topic_name="/fiducial_transforms", topic_type=FiducialTransformArray):
        super().__init__(name, topic_name, topic_type, clearing_policy= py_trees.common.ClearingPolicy.NEVER)
        self.blackboard = py_trees.blackboard.Blackboard()
        self.all_complete = False
        rospy.Subscriber(topic_name, topic_type, callback=self.callback)
        self.listener = tf.TransformListener()

    def callback(self, msg):
        try:
            for i in range(0, len(msg.transforms)):
                if(msg.transforms[i].fiducial_id in [1,2,3,4]):
                    id = msg.transforms[i].fiducial_id
                    fiducial = 'fiducial_{id}'
                    (trans, rot) = self.listener.lookupTransform('/arm_base', fiducial.format(id=id), rospy.Time(0))    
                    self.blackboard.fiducials = ({"id":id, "translation":trans, "rotation":rot} )
        except:
            pass
    def update(self):
        # status = super(Aruco_Detector, self).update()   
        
        try:
            rospy.loginfo("Fiducials ids are: {}".format(self.blackboard.fiducials.id))
            return py_trees.common.Status.SUCCESS
        except:
            return py_trees.common.Status.RUNNING
