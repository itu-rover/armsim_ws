#!/usr/bin/env python3

import py_trees
import py_trees_ros 
import rospy
import functools
import sys

from start_node import Initiliase_Arm
from marker_detector import Aruco_Detector
def create_root():
    root = py_trees.composites.Sequence("MOTHER")

    panel_look = Initiliase_Arm(name="Start panel")
    detect_marker = Aruco_Detector(name="Detect ArUco")

    root.add_child(panel_look)
    root.add_child(detect_marker)
    return root

def shutdown(behaviour_tree):
    behaviour_tree.interrupt()

if __name__=='__main__':

    rospy.init_node("test_node")

    root = create_root()
    behaviour_tree = py_trees_ros.trees.BehaviourTree(root)
    rospy.on_shutdown(functools.partial(shutdown, behaviour_tree))

    if not behaviour_tree.setup(timeout=15):
        py_trees.console.logerror("failed to setup the tree, aborting.")
        sys.exit(1)

    behaviour_tree.tick_tock(100)