#!/usr/bin/env python3

import py_trees
import moveit_commander
import sys

class Initiliase_Arm(py_trees.behaviour.Behaviour):

    def __init__(self, name: str, group_name="rover_arm"):
        super().__init__(name, group_name)
        self.group_name = group_name
        self.success = False

    def setup(self, timeout):
        
        moveit_commander.roscpp_initialize(sys.argv)
        self.move_group=moveit_commander.MoveGroupCommander(self.group_name)

        return True
    def update(self):
        
        if not self.success:
            self.move_group.set_named_target("look panel")
            self.success = self.move_group.go(wait = True)
            self.move_group.stop()
            self.move_group.clear_pose_targets()
            return py_trees.common.Status.RUNNING
        elif self.success:
            return py_trees.common.Status.SUCCESS
            